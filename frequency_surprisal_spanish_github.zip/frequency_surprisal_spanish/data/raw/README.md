# Raw data

## Included

- `childes/cds_espanol.csv` — all utterances addressed to the child by mothers, fathers and other adults in four
  Spanish corpora of CHILDES (Aguirre, Linaza, Ornat, Vila), as exported from childes-db (one row per utterance;
  34,930 utterances, 7 children, 204 transcripts). CHILDES data are shared under CC BY-NC-SA 4.0
  (https://talkbank.org/share/rules.html). Please cite MacWhinney (2000) and the individual corpora.
- `wordbank/sustantivos_aoa.csv` — the 288 noun items of the Spanish CDI with their age of acquisition (months)
  and semantic category, from Wordbank (Frank et al., 2017).

## Not included (download and place here to run Study 2)

| File | Put it in | Source |
|---|---|---|
| `joint_data_trimmed_wave2_version2_0.rda` | `data/raw/meco/` | MECO, https://osf.io/3527a/ (release 2.0 → version 2.0 → wave 2 → primary data → eye tracking data) |
| `written_es_wordlist_out.txt` | `data/raw/norms/` | EsPal word properties (Duchon et al., 2013), written-Spanish word list with `zipf` and `num_letters` |
| `SUBTLEX-ESP.xlsx` | `data/raw/norms/` | SUBTLEX-ESP (Cuetos et al., 2011), https://osf.io/xp6sz/ |
