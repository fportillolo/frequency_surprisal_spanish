`surprisal_mgpt_checkpoint_v1.json` holds the mGPT surprisal values used in preprint v1 for MECO
(passage id → one value per word). They were computed with a tokenization error and must not be used for
analysis; see CORRECTIONS.md. They are kept only so the error can be inspected and reproduced.
