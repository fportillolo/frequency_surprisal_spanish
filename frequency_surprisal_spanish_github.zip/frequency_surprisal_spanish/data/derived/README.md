# Derived data

| File | Built by | Contents |
|---|---|---|
| `study1_nouns.csv` | `src/build_study1_nouns.py` | 225 nouns: `article` (for the carrier frame), `AoA` (months), `length` (letters), `freq_tokens` (occurrences in CDS), `cd_transcripts` (transcripts containing the noun) |
| `study1_surprisal.csv` | `src/study1_surprisal.py` | per noun, surprisal in bits: `frame_*` (carrier frame) and `natural_*` (mean over natural contexts) for `mgpt`, `beto`, `bertin`; `n_contexts` |
| `study1_contexts.csv` | `src/study1_surprisal.py` | the 1,574 CDS utterances used as natural contexts, with the surprisal of the noun in each (contains CHILDES text: CC BY-NC-SA 4.0) |
| `meco_context_dataset.csv` | `src/context_matched_surprisal.py` | MECO Wave 2 Chilean Spanish, one row per participant × word (46,442 rows): `dur`, `log_dur`, `freq_espal`, `freq_subtlex`, `num_letters`, `surp_full` (full preceding passage), `surp_k20`, `surp_k10`, `surp_k5`, `surp_k3` (last k words), and `surprisal_mgpt` (v1 values, mis-tokenized; kept for comparison only) |
| `validation_report.txt` | `src/context_matched_surprisal.py` | comparison of corrected and v1 surprisal |
| `diagnosis_report.txt` | `src/diagnose_checkpoint.py` | which procedure reproduces the v1 values |

All surprisal values are in bits and summed over subword tokens.
