"""
study1_surprisal.py
===================
Recomputes every surprisal measure of Study 1 with one explicit method.

Run from the repository root (GPU recommended):  python src/study1_surprisal.py
Inputs:
    data/derived/study1_nouns.csv     225 nouns (built by src/build_study1_nouns.py)
    data/raw/childes/cds_espanol.csv  CHILDES child-directed utterances
Outputs:
    data/derived/study1_contexts.csv  the natural CDS contexts used (one row per context)
    data/derived/study1_surprisal.csv one row per noun, all surprisal measures

Method
------
Carrier frame:  "la mamá cogió {article} {noun}"  (grammatical article).
Natural contexts: up to 10 CDS utterances per noun in which the noun occurs
    as a whole word and is NOT the first word (so every context has left
    context for the autoregressive model); sampled with random_state=42.
    The same utterances are used for all three models.
mGPT (autoregressive): -log2 P(noun | preceding words), summed over the
    noun's subword tokens. Context and noun are tokenized as normal text
    (the noun keeps its leading space).
BETO, BERTIN (masked): pseudo-log-likelihood of the noun with within-word
    left-to-right masking (Kauf & Ivanova, 2023, "PLL-word-l2r"): for each
    subword token of the noun, that token and the noun's later tokens are
    masked and the token is predicted from the rest of the utterance;
    -log2 probabilities are summed. In carrier frames the noun is the last
    word, so the masked models see only the left context there too.
Per noun, natural-context surprisal is the mean over its contexts.
"""
import math
import re
import sys
import time

import numpy as np
import pandas as pd

LOG2 = math.log(2.0)
FRAME = "la mamá cogió {art}"
MODELS = {
    "mgpt": ("causal", "ai-forever/mGPT"),
    "beto": ("masked", "dccuchile/bert-base-spanish-wwm-cased"),
    "bertin": ("masked", "bertin-project/bertin-roberta-base-spanish"),
}
MAX_CONTEXTS = 10
SEED = 42


# ---------------------------------------------------------------------------
# Natural contexts
# ---------------------------------------------------------------------------
def build_contexts(nouns, cds):
    cds = cds.copy()
    cds["g"] = cds["gloss"].fillna("").astype(str).str.lower().str.strip()
    cds["toks"] = cds["g"].str.split()
    rows = []
    for w in nouns["item_definition"]:
        # whole-word occurrence that is not utterance-initial
        ok = cds["toks"].apply(lambda ts: w in ts[1:])
        m = cds[ok]
        if len(m) == 0:
            continue
        m = m.sample(min(MAX_CONTEXTS, len(m)), random_state=SEED)
        for _, r in m.iterrows():
            ts = r["toks"]
            i = ts.index(w, 1)          # first non-initial occurrence
            rows.append({"item_definition": w, "utterance_id": r.get("id"),
                         "left": " ".join(ts[:i]), "right": " ".join(ts[i + 1:]),
                         "utterance": " ".join(ts)})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------------------
# Scorers
# ---------------------------------------------------------------------------
class CausalScorer:
    def __init__(self, model, tok, device):
        self.m, self.tok, self.dev = model.to(device).eval(), tok, device

    def __call__(self, left, word, right=""):
        import torch
        ctx = self.tok(left, add_special_tokens=False)["input_ids"]
        tgt = self.tok(" " + word, add_special_tokens=False)["input_ids"]
        ids = ctx + tgt
        with torch.no_grad():
            lp = torch.log_softmax(self.m(torch.tensor([ids], device=self.dev)).logits[0].float(), -1)
        return sum(-lp[len(ctx) + j - 1, t].item() for j, t in enumerate(tgt)) / LOG2


class MaskedScorer:
    def __init__(self, model, tok, device):
        self.m, self.tok, self.dev = model.to(device).eval(), tok, device

    def target_span(self, text, start, end):
        enc = self.tok(text, return_offsets_mapping=True)
        idx = [i for i, (a, b) in enumerate(enc["offset_mapping"])
               if b > a and a < end and b > start]
        return enc["input_ids"], idx

    def __call__(self, left, word, right=""):
        import torch
        text = (left + " " if left else "") + word + (" " + right if right else "")
        start = len(left) + (1 if left else 0)
        ids, span = self.target_span(text, start, start + len(word))
        if not span:
            return float("nan")
        total = 0.0
        batch = []
        for k, pos in enumerate(span):
            x = list(ids)
            for p in span[k:]:
                x[p] = self.tok.mask_token_id
            batch.append(x)
        with torch.no_grad():
            logits = self.m(torch.tensor(batch, device=self.dev)).logits.float()
            lp = torch.log_softmax(logits, -1)
        for k, pos in enumerate(span):
            total += -lp[k, pos, ids[pos]].item()
        return total / LOG2


def load_scorer(name, device):
    import torch
    from transformers import AutoTokenizer, AutoModelForCausalLM, AutoModelForMaskedLM
    kind, mid = MODELS[name]
    tok = AutoTokenizer.from_pretrained(mid)
    if kind == "causal":
        return CausalScorer(AutoModelForCausalLM.from_pretrained(mid, torch_dtype=torch.float32), tok, device)
    return MaskedScorer(AutoModelForMaskedLM.from_pretrained(mid), tok, device)


# ---------------------------------------------------------------------------
def run(scorers, nouns, contexts):
    out = nouns[["item_definition", "article"]].copy()
    for name, sc in scorers.items():
        t0 = time.time()
        out[f"frame_{name}"] = [sc(FRAME.format(art=a), w) for w, a in zip(nouns.item_definition, nouns.article)]
        vals = [sc(l, w, r) for w, l, r in zip(contexts.item_definition, contexts.left, contexts.right)]
        contexts[f"nat_{name}"] = vals
        out = out.merge(contexts.groupby("item_definition")[f"nat_{name}"].mean().rename(f"natural_{name}"),
                        on="item_definition", how="left")
        print(f"{name}: done in {time.time() - t0:.0f}s")
    out = out.merge(contexts.groupby("item_definition").size().rename("n_contexts"),
                    on="item_definition", how="left")
    out["n_contexts"] = out["n_contexts"].fillna(0).astype(int)
    return out, contexts


def main():
    import torch
    device = "cuda" if torch.cuda.is_available() else ("mps" if torch.backends.mps.is_available() else "cpu")
    nouns = pd.read_csv("data/derived/study1_nouns.csv")
    cds = pd.read_csv("data/raw/childes/cds_espanol.csv", low_memory=False)
    contexts = build_contexts(nouns, cds)
    print(f"{len(contexts)} natural contexts for {contexts.item_definition.nunique()} nouns")
    scorers = {}
    for name in MODELS:
        print("loading", name)
        scorers[name] = load_scorer(name, device)
        # sanity check printed for the record
        print("  check:", name, "frame 'la mamá cogió la pelota' ->",
              round(scorers[name](FRAME.format(art="la"), "pelota"), 2), "bits")
    out, contexts = run(scorers, nouns, contexts)
    contexts.to_csv("data/derived/study1_contexts.csv", index=False)
    out.to_csv("data/derived/study1_surprisal.csv", index=False)
    print("Saved data/derived/study1_surprisal.csv and data/derived/study1_contexts.csv")


if __name__ == "__main__":
    main()
