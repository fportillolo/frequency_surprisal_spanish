"""
context_matched_surprisal.py
============================

Context-length control for Study 2 (MECO Wave 2, Chilean Spanish).

Question: is the surprisal effect on adult reading times only there because
the model sees a whole passage of context, while in Study 1 it only sees a
short carrier frame? To test this, we recompute mGPT surprisal for every word
of the 12 MECO passages with the context TRUNCATED to the last k words
(k = 3, 5, 10, 20), plus the original full-passage context.

The passages are rebuilt exactly as in study2_data_prep.py (same ordering,
same word cleaning, same exclusions), so the result plugs straight into the
existing analysis.

SAFETY CHECK: the full-context condition is compared against the original
surprisal_mgpt_checkpoint.json. The script stops if they do not match, so we
know the method is the same as in the paper before trusting the new numbers.

HOW TO RUN (from the repository root, GPU recommended):
    python src/context_matched_surprisal.py
Inputs: see data/raw/README.md (MECO .rda, EsPal, SUBTLEX-ESP are not redistributed here).
Output (in data/derived/):
    meco_context_dataset.csv     (one row per fixation observation)
    surprisal_by_context.json    (passage -> list of surprisals, per condition)
    validation_report.txt        (comparison with the mis-tokenized v1 values)
"""

import json
import math
import re
import sys
import time

import numpy as np
import pandas as pd

MODEL_ID = "ai-forever/mGPT"          # mGPT 1.3B (Shliazhko et al., 2022)
K_VALUES = [3, 5, 10, 20]             # truncated context lengths, in words
LOG2 = math.log(2.0)

RDA = "data/raw/meco/joint_data_trimmed_wave2_version2_0.rda"
ESPAL = "data/raw/norms/written_es_wordlist_out.txt"
SUBTLEX = "data/raw/norms/SUBTLEX-ESP.xlsx"
# Surprisal values used in preprint v1 (mis-tokenized; see CORRECTIONS.md). Used only to
# report how far the corrected values are from them.
CHECKPOINT = "data/legacy/surprisal_mgpt_checkpoint_v1.json"
OUT_DIR = "data/derived/"


# ---------------------------------------------------------------------------
# Data loading: identical to study2_data_prep.py
# ---------------------------------------------------------------------------
def limpiar_palabra(w):
    return re.sub(r"[^\wáéíóúñüÁÉÍÓÚÑÜ]", "", str(w).lower())


def load_meco(rda_path):
    import pyreadr
    result = pyreadr.read_r(rda_path)
    df_all = result[list(result.keys())[0]]
    df_es = df_all[df_all["lang"] == "sp_ch"].copy()
    df_es["itemid"] = df_es["itemid"].astype(str)
    print(f"MECO sp_ch: {len(df_es)} rows, {df_es['subid'].nunique()} participants, "
          f"{df_es['itemid'].nunique()} passages")
    return df_es


def rebuild_passages(df_es):
    """passage id -> list of dicts (sentnum, wordnum, word) in reading order."""
    pas = (
        df_es.dropna(subset=["word"])
        .drop_duplicates(subset=["itemid", "sentnum", "wordnum"])
        .sort_values(["itemid", "sentnum", "wordnum"])
    )
    return {pid: g[["sentnum", "wordnum", "word"]].to_dict("records")
            for pid, g in pas.groupby("itemid", sort=False)}


# ---------------------------------------------------------------------------
# Surprisal
# ---------------------------------------------------------------------------
class Scorer:
    """Word-level surprisal in bits = sum of subword surprisals.

    Each word is tokenized on its own, with a leading space for every word
    except the first of the passage; the passage token sequence is the
    concatenation of these pieces. This keeps word boundaries exact and makes
    the full-context and truncated-context conditions use identical tokens.
    """

    def __init__(self, model=None, tokenizer=None, device=None):
        import torch
        self.torch = torch
        if model is None:
            from transformers import AutoModelForCausalLM, AutoTokenizer
            print(f"Loading {MODEL_ID} (first run downloads ~3 GB)...")
            tokenizer = AutoTokenizer.from_pretrained(MODEL_ID)
            model = AutoModelForCausalLM.from_pretrained(MODEL_ID, torch_dtype=torch.float32)
        if device is None:
            if torch.backends.mps.is_available():
                device = "mps"
            elif torch.cuda.is_available():
                device = "cuda"
            else:
                device = "cpu"
        self.device = device
        self.model = model.to(device).eval()
        self.tok = tokenizer
        self.max_len = getattr(model.config, "n_positions", None) or \
            getattr(model.config, "max_position_embeddings", 2048)
        print(f"Model on {device}; max context {self.max_len} tokens")

    def word_pieces(self, words):
        pieces = []
        for i, w in enumerate(words):
            text = str(w) if i == 0 else " " + str(w)
            ids = self.tok(text, add_special_tokens=False)["input_ids"]
            if len(ids) == 0:
                raise ValueError(f"word {w!r} produced no tokens")
            pieces.append(ids)
        return pieces

    def _logprobs(self, ids):
        torch = self.torch
        with torch.no_grad():
            x = torch.tensor([ids], device=self.device)
            logits = self.model(x).logits[0].float()
            return torch.log_softmax(logits, dim=-1).cpu()

    def _score_target(self, ctx_ids, tgt_ids):
        """Surprisal (bits) of tgt_ids given ctx_ids (ctx must be non-empty)."""
        ids = ctx_ids + tgt_ids
        ids = ids[-self.max_len:]  # never triggered for MECO-sized inputs
        lp = self._logprobs(ids)
        n_ctx = len(ids) - len(tgt_ids)
        total = 0.0
        for j, t in enumerate(tgt_ids):
            total += -lp[n_ctx + j - 1, t].item()
        return total / LOG2

    def full_context(self, pieces):
        """One forward pass over the whole passage (teacher forcing).
        First word gets NaN, as in the original checkpoint."""
        flat = [t for p in pieces for t in p]
        if len(flat) > self.max_len:
            # Fall back to word-by-word scoring with the longest context that fits
            return [float("nan")] + [
                self._score_target([t for p in pieces[:i] for t in p][-(self.max_len - len(pieces[i])):],
                                   pieces[i]) for i in range(1, len(pieces))]
        lp = self._logprobs(flat)
        out, pos = [], 0
        for i, p in enumerate(pieces):
            if i == 0:
                out.append(float("nan"))
            else:
                out.append(sum(-lp[pos + j - 1, t].item() for j, t in enumerate(p)) / LOG2)
            pos += len(p)
        return out

    def truncated_context(self, words, k):
        """Context = the previous k words only. The context is re-tokenized
        as a fresh string (first context word without leading space), which
        is what a model sees when it is given a short frame."""
        out = []
        for i in range(len(words)):
            if i == 0:
                out.append(float("nan"))
                continue
            ctx_words = words[max(0, i - k):i]
            pieces = self.word_pieces(ctx_words + [words[i]])
            ctx = [t for p in pieces[:-1] for t in p]
            out.append(self._score_target(ctx, pieces[-1]))
        return out


    # ---- Scheme B: tokenize the joined text and map tokens back to words ----
    def _word_index_of_tokens(self, words):
        text = " ".join(str(w) for w in words)
        owner = []
        for wi, w in enumerate(words):
            if wi > 0:
                owner.append(wi)            # the space before a word belongs to that word
            owner.extend([wi] * len(str(w)))
        enc = self.tok(text, add_special_tokens=False, return_offsets_mapping=True)
        idx = []
        for (a, b) in enc["offset_mapping"]:
            pos = max(a, b - 1)
            idx.append(owner[min(pos, len(owner) - 1)])
        return enc["input_ids"], idx

    def full_context_joined(self, words):
        ids, owner = self._word_index_of_tokens(words)
        lp = self._logprobs(ids[-self.max_len:]) if len(ids) <= self.max_len else None
        if lp is None:
            raise ValueError("passage longer than model context")
        out = [0.0] * len(words)
        for j in range(len(ids)):
            if j == 0:
                continue
            out[owner[j]] += -lp[j - 1, ids[j]].item()
        first = owner[0]
        res = [x / LOG2 for x in out]
        for wi in range(len(words)):
            if wi <= first:
                res[wi] = float("nan")
        return res

    def truncated_context_joined(self, words, k):
        out = []
        for i in range(len(words)):
            if i == 0:
                out.append(float("nan"))
                continue
            sub = words[max(0, i - k):i + 1]
            ids, owner = self._word_index_of_tokens(sub)
            lp = self._logprobs(ids)
            last = len(sub) - 1
            tot = sum(-lp[j - 1, ids[j]].item() for j in range(1, len(ids)) if owner[j] == last)
            out.append(tot / LOG2)
        return out


def validate(full_by_pid, checkpoint, report, scheme=""):
    a, b = [], []
    for pid, vals in full_by_pid.items():
        ref = checkpoint[pid]
        if len(ref) != len(vals):
            report.close()
            sys.exit(f"Passage {pid}: {len(vals)} words rebuilt but checkpoint has {len(ref)}. "
                     "The passages are not rebuilt the same way as in the paper.")
        a += [x for x, y in zip(vals, ref) if not (np.isnan(x) or y is None or np.isnan(y))]
        b += [y for x, y in zip(vals, ref) if not (np.isnan(x) or y is None or np.isnan(y))]
    a, b = np.array(a), np.array(b)
    r = np.corrcoef(a, b)[0, 1]
    ratio = np.median(b / np.where(a == 0, np.nan, a))
    mad = np.median(np.abs(a - b))
    lines = [
        f"VALIDATION ({scheme}): full-context surprisal recomputed here vs. original checkpoint",
        f"  words compared:             {len(a)}",
        f"  Pearson r:                  {r:.5f}",
        f"  median ratio (orig / new):  {ratio:.4f}   (1.000 = same units; 0.693 = original in nats)",
        f"  median |difference| (bits): {mad:.4f}",
    ]
    ok = r > 0.995 and abs(ratio - 1) < 0.02
    lines.append("  RESULT: " + ("MATCH -- method reproduces the paper." if ok else
                                 "NO MATCH with this scheme."))
    text = "\n".join(lines)
    print(text)
    report.write(text + "\n")
    return ok


# ---------------------------------------------------------------------------
# Frequency norms and exclusions: identical to study2_data_prep.py
# ---------------------------------------------------------------------------
def merge_norms(d):
    d = d.copy()
    d["word_clean"] = d["word"].apply(limpiar_palabra)
    espal = pd.read_csv(ESPAL, sep="\t", encoding="utf-8-sig")
    espal.columns = [c.strip() for c in espal.columns]
    espal["word_clean"] = espal["word"].str.lower().str.strip()
    espal = espal[["word_clean", "zipf", "num_letters"]].drop_duplicates("word_clean")
    d = d.merge(espal, on="word_clean", how="left").rename(columns={"zipf": "freq_espal"})

    from openpyxl import load_workbook
    wb = load_workbook(SUBTLEX, read_only=True)
    rows = list(wb.active.iter_rows(values_only=True))[1:]
    blocks = []
    for s in [0, 5, 10]:
        blocks.append(pd.DataFrame([(r[s], r[s + 1], r[s + 2], r[s + 3]) for r in rows if r[s] is not None],
                                   columns=["word", "cnt", "per_million", "log_freq"]))
    sub = pd.concat(blocks, ignore_index=True)
    sub["word_clean"] = sub["word"].astype(str).str.lower().str.strip()
    sub = sub.drop_duplicates("word_clean")
    d = d.merge(sub[["word_clean", "log_freq"]], on="word_clean", how="left") \
         .rename(columns={"log_freq": "freq_subtlex"})
    return d


def main():
    t0 = time.time()
    report = open(OUT_DIR + "validation_report.txt", "w")
    df_es = load_meco(RDA)
    passages = rebuild_passages(df_es)
    with open(CHECKPOINT) as f:
        checkpoint = json.load(f)
    missing = set(passages) - set(checkpoint)
    if missing:
        sys.exit(f"Passages missing from checkpoint: {missing}")

    scorer = Scorer()
    conds = ["full"] + [f"k{k}" for k in K_VALUES]
    words_by_pid = {pid: [r["word"] for r in recs] for pid, recs in passages.items()}

    # Step 1: full context, scheme A; if it does not reproduce the paper, try scheme B
    full_A = {pid: scorer.full_context(scorer.word_pieces(w)) for pid, w in words_by_pid.items()}
    if validate(full_A, checkpoint, report, "scheme A: word-by-word tokens"):
        scheme, full = "A", full_A
    else:
        full_B = {pid: scorer.full_context_joined(w) for pid, w in words_by_pid.items()}
        if validate(full_B, checkpoint, report, "scheme B: joined-text tokens"):
            scheme, full = "B", full_B
        else:
            msg = ("\nNeither scheme reproduces the paper's checkpoint. Continuing with scheme A, "
                   "which is the procedure the paper describes (full preceding passage, standard "
                   "word-by-word tokenization). Results are reported for BOTH the checkpoint and "
                   "the recomputed surprisal, so the paper can be corrected.\n")
            print(msg)
            report.write(msg)
            scheme, full = "A", full_A
    print(f"Using scheme {scheme}. Now computing truncated contexts (this is the long part).")

    # Step 2: truncated contexts with the validated scheme
    surp = {"full": full}
    for k in K_VALUES:
        surp[f"k{k}"] = {}
    for n, (pid, words) in enumerate(words_by_pid.items(), 1):
        for k in K_VALUES:
            surp[f"k{k}"][pid] = (scorer.truncated_context(words, k) if scheme == "A"
                                  else scorer.truncated_context_joined(words, k))
        print(f"  passage {pid} done ({n}/{len(words_by_pid)}, {len(words)} words, "
              f"{time.time() - t0:.0f}s elapsed)")
    with open(OUT_DIR + "surprisal_by_context.json", "w") as f:
        json.dump(surp, f)

    # Long format, aligned by position; the paper's checkpoint is kept as 'surprisal_mgpt'
    rows = []
    for pid, recs in passages.items():
        for i, r in enumerate(recs):
            row = {"itemid": pid, "sentnum": r["sentnum"], "wordnum": r["wordnum"],
                   "surprisal_mgpt": checkpoint[pid][i]}
            for c in conds:
                row[f"surp_{c}"] = surp[c][pid][i]
            rows.append(row)
    s = pd.DataFrame(rows)
    d = df_es.merge(s, on=["itemid", "sentnum", "wordnum"], how="left")
    d = merge_norms(d)

    # Exclusions exactly as in the paper
    d = d[d["surprisal_mgpt"].notna()]
    d = d[d["freq_espal"].notna() & d["freq_subtlex"].notna()]
    d = d[d["dur"].notna() & (d["dur"] > 0)].copy()
    d["log_dur"] = np.log(d["dur"])

    msg = (f"\nFinal dataset: N={len(d)} (paper: 46,442), participants={d['subid'].nunique()} (45), "
           f"word types={d['word_clean'].nunique()} (888)")
    print(msg)
    report.write(msg + "\n")
    keep = ["subid", "itemid", "sentnum", "wordnum", "word", "word_clean", "dur", "log_dur",
            "freq_espal", "freq_subtlex", "num_letters", "surprisal_mgpt"] + [f"surp_{c}" for c in conds]
    d[keep].to_csv(OUT_DIR + "meco_context_dataset.csv", index=False)
    report.close()
    print(f"Saved {OUT_DIR}meco_context_dataset.csv. Total time {time.time() - t0:.0f}s.")


if __name__ == "__main__":
    main()
