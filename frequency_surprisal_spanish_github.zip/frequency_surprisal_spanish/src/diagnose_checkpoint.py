"""
diagnose_checkpoint.py
Finds out how the surprisal values of preprint v1 (data/legacy/surprisal_mgpt_checkpoint_v1.json)
were computed, by recomputing surprisal under several plausible procedures and comparing each
one with them. Result: they are reproduced exactly when words are tokenized without their
leading spaces (tokenizer(..., is_split_into_words=True)); see CORRECTIONS.md.
Run from the repository root:  python src/diagnose_checkpoint.py
Writes data/derived/diagnosis_report.txt.
"""
import json, math, re, time
import numpy as np
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import context_matched_surprisal as cms

LOG2 = math.log(2.0)
t0 = time.time()
df_es = cms.load_meco(cms.RDA)
passages = cms.rebuild_passages(df_es)
ck = json.load(open(cms.CHECKPOINT))
sc = cms.Scorer()
tok = sc.tok
BOS = tok.bos_token_id if tok.bos_token_id is not None else tok.eos_token_id
print("BOS/EOS id used:", BOS, tok.convert_ids_to_tokens([BOS]) if BOS is not None else None)


def score_with_prefix(prefix_ids, words, lead_space_first=False, spaces=True, specials=False,
                      scorer=None, agg="sum"):
    """Full-context scoring of a word list after an optional prefix of token ids.
    Returns one value per word; NaN where there is no preceding token at all.
    spaces=False: every word tokenized on its own WITHOUT a leading space.
    specials=True: every word tokenized with the tokenizer's special tokens."""
    S = scorer or sc
    pieces = []
    for i, w in enumerate(words):
        text = (" " + w) if (spaces and (i > 0 or lead_space_first)) else w
        pieces.append(S.tok(text, add_special_tokens=specials)["input_ids"])
    flat = list(prefix_ids) + [t for p in pieces for t in p]
    lp = S._logprobs(flat[-S.max_len:])
    out, pos = [], len(prefix_ids)
    for p in pieces:
        if pos == 0:
            out.append(float("nan"))
        else:
            vals = [-lp[pos + j - 1, t].item() for j, t in enumerate(p) if pos + j - 1 >= 0]
            v = sum(vals) if agg == "sum" else (sum(vals) / len(vals) if vals else float("nan"))
            out.append(v / LOG2)
        pos += len(p)
    return out


def _unused(prefix_ids, words, lead_space_first=False):
    pieces = []
    for i, w in enumerate(words):
        text = (" " + w) if (i > 0 or lead_space_first) else w
        pieces.append(tok(text, add_special_tokens=False)["input_ids"])
    flat = list(prefix_ids) + [t for p in pieces for t in p]
    lp = sc._logprobs(flat[-sc.max_len:])
    out, pos = [], len(prefix_ids)
    for p in pieces:
        if pos == 0:
            out.append(float("nan"))
        else:
            out.append(sum(-lp[pos + j - 1, t].item() for j, t in enumerate(p)) / LOG2)
        pos += len(p)
    return out


def by_sentence(recs, transform, use_bos):
    """Context restricted to the current sentence."""
    out = []
    sents = {}
    for r in recs:
        sents.setdefault(r["sentnum"], []).append(transform(r["word"]))
    for s in sorted(sents):
        out += score_with_prefix([BOS] if use_bos else [], sents[s])
    return out


raw = lambda w: str(w)
clean = cms.limpiar_palabra
lower = lambda w: str(w).lower()

variants = {
    "full passage, raw words":                lambda R: score_with_prefix([], [raw(r["word"]) for r in R]),
    "full passage, raw words, BOS":           lambda R: score_with_prefix([BOS], [raw(r["word"]) for r in R]),
    "full passage, lowercase":                lambda R: score_with_prefix([], [lower(r["word"]) for r in R]),
    "full passage, cleaned (no punct, lower)": lambda R: score_with_prefix([], [clean(r["word"]) for r in R]),
    "full passage, cleaned, BOS":             lambda R: score_with_prefix([BOS], [clean(r["word"]) for r in R]),
    "sentence only, raw, BOS":                lambda R: by_sentence(R, raw, True),
    "sentence only, raw, no BOS":             lambda R: by_sentence(R, raw, False),
    "sentence only, cleaned, BOS":            lambda R: by_sentence(R, clean, True),
    "sentence only, cleaned, no BOS":         lambda R: by_sentence(R, clean, False),
    "no context (BOS only), raw":             lambda R: [score_with_prefix([BOS], [raw(r["word"])], True)[0] for r in R],
    "no context (BOS only), cleaned":         lambda R: [score_with_prefix([BOS], [clean(r["word"])], True)[0] for r in R],
}
variants.update({
    "full passage, NO leading spaces":        lambda R: score_with_prefix([], [raw(r["word"]) for r in R], spaces=False),
    "full passage, NO spaces, BOS":           lambda R: score_with_prefix([BOS], [raw(r["word"]) for r in R], spaces=False),
    "full passage, special tokens per word":  lambda R: score_with_prefix([], [raw(r["word"]) for r in R], specials=True),
    "full passage, no spaces + specials":     lambda R: score_with_prefix([], [raw(r["word"]) for r in R], spaces=False, specials=True),
    "full passage, cleaned, NO spaces":       lambda R: score_with_prefix([], [clean(r["word"]) for r in R], spaces=False),
    "full passage, raw, MEAN over tokens":    lambda R: score_with_prefix([], [raw(r["word"]) for r in R], agg="mean"),
})
def original_notebook_method(words):
    """Exact copy of surprisal_por_palabra() from the original MECO notebook."""
    import torch, torch.nn.functional as F
    enc = tok(words, is_split_into_words=True, return_tensors="pt").to(sc.device)
    input_ids = enc["input_ids"]
    word_ids = enc.word_ids(0)
    with torch.no_grad():
        logits = sc.model(input_ids).logits
    log_probs = F.log_softmax(logits.float(), dim=-1)
    surprisal_tok = [-log_probs[0, i - 1, input_ids[0, i]].item() / LOG2 for i in range(1, input_ids.shape[1])]
    sp = {}
    for wid, v in zip(word_ids[1:], surprisal_tok):
        if wid is None:
            continue
        sp[wid] = sp.get(wid, 0.0) + v
    return [sp.get(i, float("nan")) for i in range(len(words))]

try:
    original_notebook_method(["Jano", "es", "el", "dios"])
    variants["ORIGINAL NOTEBOOK METHOD (is_split_into_words=True)"] = \
        lambda R: original_notebook_method([str(r["word"]) for r in R])
    demo = ["Jano", "es", "el", "dios"]
    a = tok(demo, is_split_into_words=True)["input_ids"]
    b = tok(" ".join(demo))["input_ids"]
    print("Tokens with is_split_into_words=True:", tok.convert_ids_to_tokens(a))
    print("Tokens of the normal text:          ", tok.convert_ids_to_tokens(b))
    DEMO = (f"\nTokens of 'Jano es el dios' as the original notebook built them: {tok.convert_ids_to_tokens(a)}"
            f"\nTokens of the same text tokenized normally:                  {tok.convert_ids_to_tokens(b)}\n")
except Exception as e:
    print("original method could not run:", e)
    DEMO = f"\nOriginal method could not run here: {e}\n"

print("special tokens added per word:", tok("casa", add_special_tokens=True)["input_ids"],
      "vs", tok("casa", add_special_tokens=False)["input_ids"])
if BOS is None:
    variants = {k: v for k, v in variants.items() if "BOS" not in k}
for k in [1, 2, 3, 5, 10]:
    variants[f"last {k} words, raw"] = (lambda k: lambda R: sc.truncated_context([r["word"] for r in R], k))(k)

lines = []
def compare(name, vals_by_pid, shift=0):
    a, b = [], []
    for pid, v in vals_by_pid.items():
        ref = ck[pid]
        for i in range(len(ref)):
            j = i + shift
            if 0 <= j < len(v) and ref[i] is not None and not np.isnan(ref[i]) and not np.isnan(v[j]):
                a.append(v[j]); b.append(ref[i])
    a, b = np.array(a), np.array(b)
    r = np.corrcoef(a, b)[0, 1]
    ratio = np.median(b / np.where(a == 0, np.nan, a))
    mad = np.median(np.abs(a - b))
    return r, ratio, mad, len(a)

results = []
first_pid = next(iter(passages))
store = {}
for name, f in variants.items():
    vals = {pid: f(R) for pid, R in passages.items()}
    store[name] = vals
    r, ratio, mad, n = compare(name, vals)
    results.append((r, name, ratio, mad, n))
    print(f"{r:7.4f}  ratio {ratio:6.3f}  |diff| {mad:6.3f}  n={n}  {name}   ({time.time()-t0:.0f}s)")

# Off-by-one check on the plain full-passage variant
for sh in (-1, 1):
    r, ratio, mad, n = compare("shift", store["full passage, raw words"], sh)
    results.append((r, f"full passage, raw words, shifted {sh:+d}", ratio, mad, n))

results.sort(reverse=True)
lines.append("Variants ranked by correlation with the paper's checkpoint")
lines.append("(r = 1.000 and ratio = 1.000 means we found the original procedure)\n")
for r, name, ratio, mad, n in results:
    lines.append(f"  r={r:.4f}  ratio={ratio:.3f}  median|diff|={mad:.3f}  n={n}  {name}")

best = results[0][1]
lines.append(f"\nBest: {best}")
lines.append(DEMO)
lines.append(f"\nFirst 25 words of passage {first_pid}: word | checkpoint | best | full passage raw")
bv = store.get(best.split(", shifted")[0], store["full passage, raw words"])
for i, rec in enumerate(passages[first_pid][:25]):
    c = ck[first_pid][i]
    lines.append(f"  {str(rec['word']):<18} {('nan' if c is None else f'{c:7.2f}'):>8} "
                 f"{bv[first_pid][i]:8.2f} {store['full passage, raw words'][first_pid][i]:8.2f}")
txt = "\n".join(lines)
print("\n" + txt)
open("data/derived/diagnosis_report.txt", "w").write(txt + "\n")
