"""
build_study1_nouns.py
Builds data/derived/study1_nouns.csv from the raw inputs:
  data/raw/wordbank/sustantivos_aoa.csv  (CDI noun items with AoA, from Wordbank)
  data/raw/childes/cds_espanol.csv       (child-directed utterances from CHILDES)

Selection: of the 288 CDI noun items, keep single-word items (no space, slash,
parenthesis or asterisk) that occur at least once in the corpus -> 225 nouns.
Measures:
  freq_tokens     number of occurrences of the exact (lower-cased) word form
  cd_transcripts  number of transcripts in which the word occurs
  article         grammatical definite article for the carrier frame
  length          number of letters

Run from the repository root:  python src/build_study1_nouns.py
"""
from collections import Counter
import pandas as pd

RAW_AOA = "data/raw/wordbank/sustantivos_aoa.csv"
RAW_CDS = "data/raw/childes/cds_espanol.csv"
OUT = "data/derived/study1_nouns.csv"

# Articles: rule-based, with the exceptions checked by hand.
FEMININE_EXCEPTIONS = {"calle", "luz", "flor", "leche", "nube", "nariz", "bici", "nieve",
                       "serpiente", "tata", "mano", "moto", "radio", "foto"}
PLURAL_FEMININE = {"llaves"}
STRESSED_A_FEMININE = {"agua"}          # el agua
MASCULINE_IN_A = {"día", "mapa", "sofá", "pijama"}


def article(w):
    if w in STRESSED_A_FEMININE:
        return "el"
    if w in PLURAL_FEMININE:
        return "las"
    if w.endswith("s") and w not in {"autobús", "lápiz"}:
        sing = w[:-2] if w.endswith("es") and w[:-2][-1:] in "lnrzd" else w[:-1]
        return "las" if sing.endswith("a") else "los"
    if w in FEMININE_EXCEPTIONS:
        return "la"
    if w.endswith(("a", "ción", "sión", "dad", "tud", "umbre", "ie")) and w not in MASCULINE_IN_A:
        return "la"
    return "el"


def main():
    aoa = pd.read_csv(RAW_AOA)
    cds = pd.read_csv(RAW_CDS, low_memory=False)
    toks = cds["gloss"].fillna("").astype(str).str.lower().str.split()
    counts = Counter(t for ts in toks for t in ts)

    single = aoa[~aoa["item_definition"].str.contains(r"[ /()*]", regex=True)].copy()
    rows = []
    for w, a in zip(single["item_definition"], single["AoA"]):
        f = counts.get(w, 0)
        if f == 0:
            continue
        has = toks.apply(lambda ts: w in ts)
        rows.append({"item_definition": w, "article": article(w), "AoA": a, "length": len(w),
                     "freq_tokens": f, "cd_transcripts": cds.loc[has, "transcript_id"].nunique()})
    out = pd.DataFrame(rows)
    print(f"CDI noun items: {len(aoa)} | single-word: {len(single)} | in corpus: {len(out)}")
    out.to_csv(OUT, index=False)
    print("Saved", OUT)


if __name__ == "__main__":
    main()
