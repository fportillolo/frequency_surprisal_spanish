# Corrections to preprint v1

While extending the analyses in November 2026, I found several errors in how the measures of the first version
of the preprint were computed or described. All of them are fixed in this repository and in the revised paper.
I list them here so that anyone who read v1 can see exactly what changed and why.

## 1. Study 2: mGPT surprisal was computed without spaces between words

In v1, each passage was tokenized with `tokenizer(words, is_split_into_words=True)`. With mGPT's tokenizer this
encodes every word as if it were at the start of a text, without the leading space that marks a word boundary.
The model therefore saw the passage as one long string without spaces, e.g.

```
v1:        ['J', 'ano', 'es', 'el', 'd', 'ios']
corrected: ['J', 'ano', 'Ġes', 'Ġel', 'Ġdios']
```

This inflated surprisal (mean 8.04 vs. 4.64 bits) and weakened its relation to context (for example, *dios*
in "Jano es el dios de los comienzos" had 14.9 bits in v1 and 1.8 bits with correct tokenization).
`src/diagnose_checkpoint.py` reproduces the v1 values exactly (r = 1.000) with this procedure, and
`data/derived/diagnosis_report.txt` shows the comparison. The v1 values are kept in `data/legacy/` for reference.

**Effect on the results:** the reading effect holds with corrected surprisal (standardized β = .087 instead of
.112; both p < .001), and also holds when the model sees only the previous three words.

## 2. Study 1: carrier sentences with the wrong article

The carrier sentence used a fixed article for many nouns, producing ungrammatical sentences for 23 of the 225
nouns (e.g. *el serpiente*, *la agua*, *el luz*, *el ojos*, *la tijeras*). Ungrammatical frames raise surprisal
for reasons unrelated to the noun. The corrected frames use the right article for every noun
(`src/build_study1_nouns.py`).

## 3. Study 1: the "BETO (carrier frame)" values were not from the carrier frame

In v1, the BETO row of the main table came from BETO surprisal averaged over natural CHILDES utterances (and
averaged, not summed, over subword tokens), while the text described it as carrier-frame surprisal. In the
corrected version, all three models are computed with the same procedure, in both the carrier frame and natural
contexts, and both conditions are reported.

## 4. Study 1: natural contexts matched words inside other words

The v1 search for a noun inside an utterance used plain substring matching, so for example *pan* could be found
inside *pantalón*. Natural contexts are now selected by whole-word matching, and the noun is never the first word
of the utterance (so the autoregressive model always has preceding context).

## 5. Study 1: frequency and contextual diversity

The v1 "frequency" was the number of utterances containing the noun, not the number of occurrences (the two
correlate at r = .999, so results are unchanged). The v1 "contextual diversity" values could not be reproduced
from the corpus and in 131 of 225 nouns exceeded the frequency count, which is impossible under the stated
definition. Contextual diversity is now the number of transcripts in which the noun occurs.

## What changes in the conclusions

- **Holds:** frequency strongly predicts AoA (ρ = −.59); surprisal adds no reliable variance beyond frequency and
  length; surprisal predicts adult reading times beyond frequency and length.
- **New:** with corrected frames, surprisal is *positively correlated* with AoA on its own (ρ = .14 to .31), but
  this overlaps with frequency. The reading effect survives with only three words of context.
- **Withdrawn:** v1 claimed that the difference between the two studies was statistically reliable (Fisher z on raw
  correlations). With corrected measures that comparison is no longer significant for carrier-frame surprisal, so
  the revised paper does not make that claim.
