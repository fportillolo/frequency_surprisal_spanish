# Installs the R packages used by analysis_all.R and make_figures.R
pkgs <- c("lme4", "lmerTest", "ggplot2", "patchwork")
miss <- pkgs[!vapply(pkgs, requireNamespace, logical(1), quietly = TRUE)]
if (length(miss)) install.packages(miss, repos = "https://cloud.r-project.org")
cat("R packages ready:", paste(pkgs, collapse = ", "), "\n")
