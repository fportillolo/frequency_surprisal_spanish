# make_figures.R -- figures for the CogSci 2027 submission
# Run from the repository root, after analysis_all.R:  Rscript analysis/make_figures.R
# Output: figures/fig1_aoa.pdf, figures/fig2_context.pdf, figures/fig3_unique.pdf (+ PNG copies if pdftoppm is installed)
suppressPackageStartupMessages({ library(ggplot2); library(patchwork) })

FONT <- "Liberation Serif"   # metric clone of Times; use "Times New Roman" on Mac/Windows
COL_CORPUS <- "#1F3A5F"; COL_LLM <- "#7A1F1F"; COL_READ <- "#1F3A5F"; COL_AOA <- "#7A1F1F"
MINUS <- "−"
dir.create("figures", showWarnings = FALSE)
lab_num <- function(x) { out <- sub("-", MINUS, format(x, trim = TRUE, drop0trailing = TRUE), fixed = TRUE); out[x == 0] <- "0"; out }
lab_r <- function(x) { out <- sub("^(-?)0\\.", "\\1.", format(x, trim = TRUE, drop0trailing = TRUE)); out <- sub("-", MINUS, out, fixed = TRUE); out[x == 0] <- "0"; out }
fmt_r <- function(r) sub("-", MINUS, sub("^(-?)0", "\\1", sprintf("%.2f", r)), fixed = TRUE)
fmt_p <- function(p) if (p < .001) "p < .001" else paste0("p = ", sub("^0", "", sprintf("%.3f", p)))

theme_paper <- function(base = 8) theme_classic(base_size = base, base_family = FONT) + theme(
  axis.line = element_line(linewidth = .3), axis.ticks = element_line(linewidth = .3),
  axis.text = element_text(colour = "black", size = base - 1), axis.title = element_text(size = base),
  plot.title = element_text(face = "bold", size = base, hjust = .5, margin = margin(b = 2)),
  plot.margin = margin(3, 4, 3, 3), legend.position = "none")

# ---------------------------------------------------------------- Figure 1
s1 <- read.csv("results/fig_data_study1.csv", encoding = "UTF-8")
set.seed(2027); jit <- runif(nrow(s1), -.2, .2)
panels <- list(
  list(x = log1p(s1$freq_tokens), raw = s1$freq_tokens, t = "Frequency in CDS", xl = "log(1 + frequency)", col = COL_CORPUS),
  list(x = s1$frame_mgpt,   raw = s1$frame_mgpt,   t = "mGPT surprisal",   xl = "Surprisal (bits)", col = COL_LLM),
  list(x = s1$frame_beto,   raw = s1$frame_beto,   t = "BETO surprisal",   xl = "Surprisal (bits)", col = COL_LLM),
  list(x = s1$frame_bertin, raw = s1$frame_bertin, t = "BERTIN surprisal", xl = "Surprisal (bits)", col = COL_LLM))
mk <- function(p, i) {
  ct <- suppressWarnings(cor.test(p$raw, s1$AoA, method = "spearman", exact = FALSE))
  df <- data.frame(x = p$x, y = s1$AoA, yj = s1$AoA + jit)
  g <- ggplot(df, aes(x, y)) +
    geom_point(aes(y = yj), colour = p$col, alpha = .45, size = .7, stroke = 0) +
    geom_smooth(method = "lm", formula = y ~ x, colour = "black", fill = "grey70", linewidth = .45, alpha = .5) +
    scale_x_continuous(labels = lab_num) +
    scale_y_continuous(limits = c(15.5, 31.3), breaks = seq(16, 30, 2), expand = c(0, 0)) +
    labs(title = paste0(p$t, "\n\u03C1 = ", fmt_r(ct$estimate), ", ", fmt_p(ct$p.value)), x = p$xl, y = if (i == 1) "AoA (months)" else NULL) + theme_paper()
  if (i > 1) g <- g + theme(axis.text.y = element_blank())
  g
}
ggsave("figures/fig1_aoa.pdf", wrap_plots(Map(mk, panels, seq_along(panels)), nrow = 1),
       device = cairo_pdf, width = 7, height = 2.05)

# ---------------------------------------------------------------- Figure 2
e <- read.csv("results/fig_data_study2_effects.csv")
e <- e[e$condition != "surprisal_mgpt", ]
lev <- c("Last 3 words", "Last 5 words", "Last 10 words", "Last 20 words", "Full passage")
e$label <- factor(e$label, levels = lev, labels = c("3", "5", "10", "20", "Full"))
e$norm <- factor(e$norm, levels = c("freq_espal", "freq_subtlex"), labels = c("EsPal", "SUBTLEX-ESP"))
f2 <- ggplot(e, aes(label, bS, shape = norm, group = norm)) +
  geom_hline(yintercept = 0, linewidth = .3, linetype = "dashed", colour = "grey40") +
  geom_errorbar(aes(ymin = loS, ymax = hiS), width = .15, linewidth = .35, position = position_dodge(.4)) +
  geom_point(size = 1.5, fill = "white", position = position_dodge(.4)) +
  scale_shape_manual(values = c(16, 21), name = "Frequency norm") +
  scale_y_continuous(limits = c(0, .11), breaks = seq(0, .1, .02), labels = function(x) ifelse(x == 0, "0", sprintf("%.2f", x)), expand = c(0, 0)) +
  labs(x = "Context given to mGPT (preceding words)", y = "Standardized surprisal effect (β)") +
  theme_paper() + theme(legend.position = c(.25, .88), legend.title = element_text(size = 7),
                        legend.text = element_text(size = 7), legend.key.height = unit(8, "pt"),
                        legend.background = element_blank())
ggsave("figures/fig2_context.pdf", f2, device = cairo_pdf, width = 3.3, height = 2.2)

# ---------------------------------------------------------------- Figure 3
pr <- read.csv("results/fig_data_partials.csv", encoding = "UTF-8")
pr <- pr[pr$measure != "Original (mis-tokenized)", ]
pr$measure <- sub("Last (\\d+) words", "mGPT, last \\1 words", pr$measure)
pr$measure <- sub("^Full passage$", "mGPT, full passage", pr$measure)
ord <- c("BERTIN, natural", "BETO, natural", "mGPT, natural", "BERTIN, frame", "BETO, frame", "mGPT, frame",
         "mGPT, last 3 words", "mGPT, last 5 words", "mGPT, last 10 words", "mGPT, last 20 words", "mGPT, full passage")
pr$measure <- factor(pr$measure, levels = ord)
pr$study <- factor(pr$study, levels = c("Reading (MECO)", "Acquisition (AoA)"))
f3 <- ggplot(pr, aes(r, measure, colour = study)) +
  geom_vline(xintercept = 0, linewidth = .3, linetype = "dashed", colour = "grey40") +
  geom_errorbarh(aes(xmin = lo, xmax = hi), height = .25, linewidth = .4) +
  geom_point(size = 1.4) +
  facet_grid(study ~ ., scales = "free_y", space = "free_y") +
  scale_colour_manual(values = c(COL_READ, COL_AOA)) +
  scale_x_continuous(limits = c(-.2, .3), breaks = seq(-.2, .3, .1), labels = lab_r) +
  labs(x = "Partial Spearman correlation with behavior (95% CI)", y = NULL) +
  theme_paper() + theme(strip.background = element_blank(), strip.text.y = element_text(size = 7, angle = -90),
                        panel.spacing = unit(4, "pt"))
ggsave("figures/fig3_unique.pdf", f3, device = cairo_pdf, width = 3.3, height = 2.6)
# PNG copies for the README
for (f in c("fig1_aoa", "fig2_context", "fig3_unique")) {
  pdf_file <- file.path("figures", paste0(f, ".pdf"))
  if (nzchar(Sys.which("pdftoppm")))
    system2("pdftoppm", c("-r", "200", "-png", "-singlefile", pdf_file, file.path("figures", f)))
}
cat("Figures done.\n")
