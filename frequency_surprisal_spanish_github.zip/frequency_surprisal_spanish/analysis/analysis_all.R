# analysis_all.R
# Every number reported in the paper comes from this script.
# Inputs:  study1_nouns.csv, study1_surprisal.csv, meco_context_dataset.csv
# Output:  results/numbers.txt, results/fig_data_*.csv
#
# Run from the repository root:  Rscript analysis/analysis_all.R

suppressPackageStartupMessages({ library(lme4); library(lmerTest) })
options(width = 120)
sink("results/numbers.txt", split = TRUE)
z <- function(x) as.numeric(scale(x))
p_fmt <- function(p) if (p < .001) "<.001" else sprintf("%.3f", p)

# Rank-based partial correlation (Spearman) of x and y controlling covs,
# with a Fisher-z 95% CI (df adjusted for the number of covariates).
partial_rho <- function(x, y, covs) {
  ok <- complete.cases(x, y, covs)
  R <- data.frame(x = rank(x[ok]), y = rank(y[ok]), sapply(as.data.frame(covs)[ok, , drop = FALSE], rank))
  k <- ncol(R) - 2
  rx <- resid(lm(x ~ ., data = R[, -2])); ry <- resid(lm(y ~ ., data = R[, -1]))
  r <- cor(rx, ry); n <- sum(ok)
  t <- r * sqrt((n - 2 - k) / (1 - r^2)); p <- 2 * pt(-abs(t), n - 2 - k)
  se <- 1 / sqrt(n - 3 - k); ci <- tanh(atanh(r) + c(-1, 1) * 1.96 * se)
  c(r = r, lo = ci[1], hi = ci[2], p = p, n = n, k = k)
}

# =============================================================================
cat("=================== STUDY 1: AoA ===================\n")
s1 <- merge(read.csv("data/derived/study1_nouns.csv", encoding = "UTF-8"),
            read.csv("data/derived/study1_surprisal.csv", encoding = "UTF-8"), by = c("item_definition", "article"))
cat(sprintf("Nouns: %d | AoA range %g-%g months (M = %.1f, SD = %.1f)\n",
            nrow(s1), min(s1$AoA), max(s1$AoA), mean(s1$AoA), sd(s1$AoA)))
cat(sprintf("Frequency (tokens): median %g, range %g-%g | CD (transcripts): median %g, range %g-%g\n",
            median(s1$freq_tokens), min(s1$freq_tokens), max(s1$freq_tokens),
            median(s1$cd_transcripts), min(s1$cd_transcripts), max(s1$cd_transcripts)))
cat(sprintf("Natural contexts: total %d, nouns with >=1: %d, with >=5: %d, with 10: %d, median per noun %g\n",
            sum(s1$n_contexts), sum(s1$n_contexts > 0), sum(s1$n_contexts >= 5),
            sum(s1$n_contexts == 10), median(s1$n_contexts[s1$n_contexts > 0])))
s1$lf <- log1p(s1$freq_tokens)

surp_cols <- c(frame_mgpt = "mGPT, frame", frame_beto = "BETO, frame", frame_bertin = "BERTIN, frame",
               natural_mgpt = "mGPT, natural", natural_beto = "BETO, natural", natural_bertin = "BERTIN, natural")

cat("\n--- Table 1: Spearman correlations with AoA ---\n")
t1 <- data.frame()
for (v in c("freq_tokens", "cd_transcripts", names(surp_cols))) {
  ct <- suppressWarnings(cor.test(s1[[v]], s1$AoA, method = "spearman", exact = FALSE))
  t1 <- rbind(t1, data.frame(var = v, rho = ct$estimate, p = ct$p.value, n = sum(!is.na(s1[[v]]))))
}
pr <- partial_rho(s1$cd_transcripts, s1$AoA, data.frame(s1$lf))
t1 <- rbind(t1, data.frame(var = "cd | freq", rho = pr["r"], p = pr["p"], n = pr["n"]))
pr <- partial_rho(s1$lf, s1$AoA, data.frame(s1$cd_transcripts))
t1 <- rbind(t1, data.frame(var = "freq | cd", rho = pr["r"], p = pr["p"], n = pr["n"]))
for (i in seq_len(nrow(t1))) cat(sprintf("%-16s rho = %+.3f  p = %s  N = %d\n", t1$var[i], t1$rho[i], p_fmt(t1$p[i]), t1$n[i]))
cat(sprintf("Spearman frequency vs CD: %.3f\n", cor(s1$freq_tokens, s1$cd_transcripts, method = "spearman")))
for (v in names(surp_cols))
  cat(sprintf("Spearman %s vs frequency: %+.3f\n", v, cor(s1[[v]], s1$freq_tokens, method = "spearman", use = "complete.obs")))

incr <- function(d, v) {
  d <- d[!is.na(d[[v]]), ]
  d$y <- z(d$AoA); d$F <- z(d$lf); d$L <- z(d$length); d$S <- z(d[[v]])
  m0 <- lm(y ~ F + L, d); m1 <- lm(y ~ F + L + S, d)
  a <- anova(m0, m1); cf <- coef(summary(m1))["S", ]
  data.frame(var = v, n = nrow(d), r2_base = summary(m0)$r.squared, r2_full = summary(m1)$r.squared,
             dr2 = summary(m1)$r.squared - summary(m0)$r.squared, beta = cf[1], se = cf[2], p = cf[4],
             F = a$F[2], df2 = a$Res.Df[2])
}
cat("\n--- Table 2: surprisal beyond log frequency + length (z-scored OLS) ---\n")
base <- lm(z(AoA) ~ z(lf) + z(length), s1)
cat("Baseline coefficients:\n"); print(round(coef(summary(base)), 3))
t2 <- do.call(rbind, lapply(names(surp_cols), function(v) incr(s1, v)))
for (i in seq_len(nrow(t2))) with(t2[i, ], cat(sprintf(
  "%-15s N=%d R2 base=%.3f full=%.3f dR2=%.4f beta=%+.3f SE=%.3f p=%s F(1,%d)=%.2f\n",
  var, n, r2_base, r2_full, dr2, beta, se, p_fmt(p), df2, F)))
cat("\n--- Robustness: nouns with >= 5 natural contexts ---\n")
r5 <- s1[s1$n_contexts >= 5, ]
for (v in c("natural_mgpt", "natural_beto", "natural_bertin")) {
  ct <- suppressWarnings(cor.test(r5[[v]], r5$AoA, method = "spearman", exact = FALSE)); x <- incr(r5, v)
  cat(sprintf("%-15s N=%d rho=%+.3f p=%s | dR2=%.4f beta=%+.3f p=%s\n", v, x$n, ct$estimate, p_fmt(ct$p.value), x$dr2, x$beta, p_fmt(x$p)))
}
cat("\n--- Robustness: Spearman-based partial correlations with AoA (controlling log freq + length) ---\n")
pa <- data.frame()
for (v in names(surp_cols)) {
  q <- partial_rho(s1[[v]], s1$AoA, data.frame(s1$lf, s1$length))
  pa <- rbind(pa, data.frame(study = "Acquisition (AoA)", measure = surp_cols[[v]], r = q["r"], lo = q["lo"], hi = q["hi"], p = q["p"], n = q["n"]))
  cat(sprintf("%-16s partial rho = %+.3f [%+.3f, %+.3f] p = %s n = %d\n", surp_cols[[v]], q["r"], q["lo"], q["hi"], p_fmt(q["p"]), q["n"]))
}
write.csv(s1, "results/fig_data_study1.csv", row.names = FALSE)

# =============================================================================
cat("\n=================== STUDY 2: MECO reading ===================\n")
d <- read.csv("data/derived/meco_context_dataset.csv", encoding = "UTF-8")
d$subid <- factor(d$subid); d$word_clean <- factor(d$word_clean)
cat(sprintf("N = %d observations | %d participants | %d passages | %d word types | %d word positions\n",
            nrow(d), nlevels(d$subid), length(unique(d$itemid)), nlevels(d$word_clean),
            nrow(unique(d[, c("itemid", "sentnum", "wordnum")]))))
cat(sprintf("Spearman EsPal vs SUBTLEX-ESP (tokens): %.3f ; Pearson: %.3f\n",
            cor(d$freq_espal, d$freq_subtlex, method = "spearman"), cor(d$freq_espal, d$freq_subtlex)))
cat(sprintf("Original (mis-tokenized) vs recomputed full-context surprisal, word positions: r = %.3f\n",
            with(unique(d[, c("itemid", "sentnum", "wordnum", "surprisal_mgpt", "surp_full")]), cor(surprisal_mgpt, surp_full))))
cat(sprintf("Mean surprisal (bits) original %.2f vs recomputed %.2f\n",
            mean(unique(d[, c("itemid","sentnum","wordnum","surprisal_mgpt")])$surprisal_mgpt),
            mean(unique(d[, c("itemid","sentnum","wordnum","surp_full")])$surp_full)))

cat("\n--- Table 3: lmer, recomputed full-context surprisal ---\n")
for (norm in c("freq_espal", "freq_subtlex")) {
  d$F <- d[[norm]]
  m <- lmer(log_dur ~ surp_full + F + num_letters + (1 | subid) + (1 | word_clean), data = d)
  cat(sprintf("\n[%s]\n", norm)); print(round(coef(summary(m)), 5))
  print(VarCorr(m))
}
# spillover
pos <- unique(d[, c("itemid", "sentnum", "wordnum", "surp_full")])
pos <- pos[order(pos$itemid, pos$sentnum, pos$wordnum), ]
pos$prev <- ave(pos$surp_full, pos$itemid, FUN = function(x) c(NA, head(x, -1)))
d <- merge(d, pos[, c("itemid", "sentnum", "wordnum", "prev")], by = c("itemid", "sentnum", "wordnum"), all.x = TRUE)
cat("\n--- Spillover (previous word surprisal; ML fits) ---\n")
for (norm in c("freq_espal", "freq_subtlex")) {
  d$F <- d[[norm]]; dd <- d[!is.na(d$prev), ]
  m1 <- lmer(log_dur ~ surp_full + prev + F + num_letters + (1 | subid) + (1 | word_clean), dd, REML = FALSE)
  m0 <- lmer(log_dur ~ surp_full + F + num_letters + (1 | subid) + (1 | word_clean), dd, REML = FALSE)
  a <- anova(m0, m1); cf <- coef(summary(m1))
  cat(sprintf("%s: N=%d current b=%.4f (SE %.5f, p=%s) | previous b=%.4f (SE %.5f, p=%s) | chi2(1)=%.2f p=%s\n",
              norm, nrow(dd), cf["surp_full", 1], cf["surp_full", 2], p_fmt(cf["surp_full", 5]),
              cf["prev", 1], cf["prev", 2], p_fmt(cf["prev", 5]), a$Chisq[2], p_fmt(a$`Pr(>Chisq)`[2])))
}

cat("\n--- Surprisal effect by context condition (EsPal and SUBTLEX) ---\n")
conds <- c(surp_full = "Full passage", surp_k20 = "Last 20 words", surp_k10 = "Last 10 words",
           surp_k5 = "Last 5 words", surp_k3 = "Last 3 words", surprisal_mgpt = "Original (mis-tokenized)")
eff <- data.frame()
for (cn in names(conds)) for (norm in c("freq_espal", "freq_subtlex")) {
  ds <- data.frame(y = z(d$log_dur), S = z(d[[cn]]), F = z(d[[norm]]), L = z(d$num_letters), subid = d$subid, word_clean = d$word_clean)
  mz <- lmer(y ~ S + F + L + (1 | subid) + (1 | word_clean), ds)
  m1 <- lmer(y ~ S + F + L + (1 | subid) + (1 | word_clean), ds, REML = FALSE)
  m0 <- lmer(y ~     F + L + (1 | subid) + (1 | word_clean), ds, REML = FALSE)
  a <- anova(m0, m1); ci <- confint(mz, parm = c("S", "F", "L"), method = "Wald")
  eff <- rbind(eff, data.frame(condition = cn, label = conds[[cn]], norm = norm,
    bS = fixef(mz)[["S"]], loS = ci["S", 1], hiS = ci["S", 2],
    bF = fixef(mz)[["F"]], loF = ci["F", 1], hiF = ci["F", 2],
    bL = fixef(mz)[["L"]], loL = ci["L", 1], hiL = ci["L", 2],
    chisq = a$Chisq[2], p = a$`Pr(>Chisq)`[2], dAIC = AIC(m0) - AIC(m1)))
}
for (i in seq_len(nrow(eff))) with(eff[i, ], cat(sprintf(
  "%-25s %-13s beta_S=%.3f [%.3f, %.3f] beta_F=%.3f [%.3f, %.3f] beta_L=%.3f [%.3f, %.3f] chi2(1)=%.1f p=%s dAIC=%.1f\n",
  label, norm, bS, loS, hiS, bF, loF, hiF, bL, loL, hiL, chisq, p_fmt(p), dAIC)))
write.csv(eff, "results/fig_data_study2_effects.csv", row.names = FALSE)

cat("\n--- Word-type level (888 types): raw and partial Spearman, surprisal vs mean log duration ---\n")
agg <- aggregate(cbind(log_dur, freq_espal, num_letters, surp_full, surp_k20, surp_k10, surp_k5, surp_k3, surprisal_mgpt) ~ word_clean, d, mean)
pb <- data.frame()
for (cn in names(conds)) {
  rr <- cor(agg[[cn]], agg$log_dur, method = "spearman")
  q <- partial_rho(agg[[cn]], agg$log_dur, data.frame(agg$freq_espal, agg$num_letters))
  pb <- rbind(pb, data.frame(study = "Reading (MECO)", measure = conds[[cn]], r = q["r"], lo = q["lo"], hi = q["hi"], p = q["p"], n = q["n"]))
  cat(sprintf("%-25s raw rho=%.3f | partial rho=%.3f [%.3f, %.3f] p=%s n=%d\n", conds[[cn]], rr, q["r"], q["lo"], q["hi"], p_fmt(q["p"]), q["n"]))
}
write.csv(rbind(pa, pb), "results/fig_data_partials.csv", row.names = FALSE)

cat("\n--- Cross-study: Fisher z on partial correlations (descriptive) ---\n")
fz <- function(a, b) { z <- (atanh(a$r) - atanh(b$r)) / sqrt(1 / (a$n - 5) + 1 / (b$n - 5)); c(z, 2 * pnorm(-abs(z))) }
for (rm in c("Full passage", "Last 5 words", "Last 3 words")) for (am in c("mGPT, frame", "mGPT, natural")) {
  x <- fz(pb[pb$measure == rm, ], pa[pa$measure == am, ])
  cat(sprintf("Reading %-13s vs AoA %-14s z = %.2f p = %s\n", rm, am, x[1], p_fmt(x[2])))
}
cat("\nSession: "); cat(R.version.string, "| lme4", as.character(packageVersion("lme4")), "| lmerTest", as.character(packageVersion("lmerTest")), "\n")
sink()
