# From Exposure to Expectation

**Frequency, surprisal, and language across development in Spanish**

Francisco Portillo

Do children learn first the words they hear most often, or the words that are easiest to predict? And is the
predictability measure that works so well for adult reading also useful for explaining word learning?

This repository contains the data, code and results for two corpus studies of Spanish that compare
**cumulative exposure** (how often a word is heard) with **contextual predictability** (surprisal from
language models):

- **Study 1 — acquisition.** Age of acquisition (AoA) of 225 Spanish nouns from Wordbank, predicted from
  their frequency in child-directed speech (CHILDES) and from surprisal computed with three language models
  (mGPT, BETO, BERTIN), both in a carrier sentence and in real child-directed utterances.
- **Study 2 — reading.** Eye-tracking data from Chilean Spanish readers (MECO Wave 2), predicted from mGPT
  surprisal computed with the full preceding passage and with the context cut to the last 20, 10, 5 or 3 words.

Every number and figure in the paper is produced by the code here, and can be regenerated in a few minutes
from the files in `data/derived/`.

> **Note on versions.** The first version of the preprint contained errors in how some surprisal values were
> computed. They are documented in [CORRECTIONS.md](CORRECTIONS.md). Everything in this repository is the
> corrected version.

---

## Main results

**1. Exposure predicts when children learn nouns.** Nouns heard more often are learned earlier
(Spearman ρ = −.59, N = 225).

**2. Predictability is related to AoA, but mostly through frequency.** Nouns that the models find more
surprising are learned later (ρ = .14 to .31 across six measures), but surprisal is also correlated with
frequency. Beyond log frequency and word length, no surprisal measure explains reliable additional variance
(ΔR² ≤ .011; none significant after Holm correction).

![Figure 1](figures/fig1_aoa.png)

**3. In reading, surprisal has a clear effect of its own, even with very little context.** mGPT surprisal
predicts total fixation duration beyond frequency and length (standardized β = .087, 95% CI [.073, .100]),
with either frequency norm and after controlling for spillover. With only the previous three words as
context, the effect is smaller but still clear (β = .050 [.034, .066]).

<img src="figures/fig2_context.png" width="420">

**4. Putting the two studies side by side.** Controlling for frequency and length, the association between
surprisal and behavior is well above zero in reading at every context length, and close to zero in
acquisition for five of the six measures.

<img src="figures/fig3_unique.png" width="420">

Full output: [`results/numbers.txt`](results/numbers.txt).

---

## Reproducing the results

### Level 1: every number and figure, from the derived data (≈ 5 minutes, no GPU)

Requires R (≥ 4.2). From the repository root:

```bash
Rscript analysis/install_packages.R   # lme4, lmerTest, ggplot2, patchwork
Rscript analysis/analysis_all.R       # -> results/numbers.txt and results/fig_data_*.csv
Rscript analysis/make_figures.R       # -> figures/*.pdf
```

The figures use the font *Liberation Serif* (a metric clone of Times). On a Mac or Windows machine without
it, change `FONT` at the top of `analysis/make_figures.R` to `"Times New Roman"`.

### Level 2: recompute all surprisal values (GPU, ≈ 30 minutes)

Open [`notebooks/recompute_surprisal_colab.ipynb`](notebooks/recompute_surprisal_colab.ipynb) in Google
Colab. It clones this repository and runs, in order:

| Step | Script | Output |
|---|---|---|
| Select nouns, count frequency and contextual diversity | `src/build_study1_nouns.py` | `data/derived/study1_nouns.csv` |
| Study 1 surprisal (3 models × frame / natural contexts) | `src/study1_surprisal.py` | `data/derived/study1_surprisal.csv`, `study1_contexts.csv` |
| Study 2 surprisal (full and truncated context) | `src/context_matched_surprisal.py` | `data/derived/meco_context_dataset.csv` |
| How the v1 values were produced (optional) | `src/diagnose_checkpoint.py` | `data/derived/diagnosis_report.txt` |
| Analysis and figures | `analysis/*.R` | `results/`, `figures/` |

Study 2 needs three files that are not redistributed here; see [`data/raw/README.md`](data/raw/README.md).

---

## Methods in brief

- **Models.** [mGPT](https://huggingface.co/ai-forever/mGPT) (autoregressive, 1.3B),
  [BETO](https://huggingface.co/dccuchile/bert-base-spanish-wwm-cased) and
  [BERTIN](https://huggingface.co/bertin-project/bertin-roberta-base-spanish) (masked).
- **Surprisal.** mGPT: −log₂ P(word | preceding words), with words tokenized as in running text (with their
  leading space), summed over subword tokens. Masked models: pseudo-log-likelihood with within-word
  left-to-right masking (PLL-word-l2r; Kauf & Ivanova, 2023), summed over subword tokens.
- **Carrier frame.** *la mamá cogió* [*el/la/los/las*] *N* ("mom picked up the N"), with the grammatical
  article for each noun.
- **Natural contexts.** Up to 10 child-directed utterances per noun in which the noun occurs as a whole word
  and not as the first word (random sample, seed 42); surprisal averaged per noun.
- **Corpus measures.** Frequency = occurrences of the exact word form; contextual diversity = number of
  transcripts containing the word. Corpus: all adult utterances in the Aguirre, Linaza, Ornat and Vila
  corpora of CHILDES (34,930 utterances, 7 children, 11–59 months).
- **Reading.** MECO Wave 2, Chilean Spanish (45 participants, 12 passages, 46,442 observations after
  excluding passage-initial words, words missing from either norm, and skipped words). Linear mixed-effects
  models with crossed random intercepts for participants and words.

---

## Repository structure

```
analysis/        R scripts: every reported number (analysis_all.R) and figure (make_figures.R)
data/raw/        inputs: CHILDES utterances, Wordbank AoA (MECO and norms: see data/raw/README.md)
data/derived/    computed measures used by the analysis (see data/derived/README.md)
data/legacy/     surprisal values from preprint v1, kept for transparency (do not use)
figures/         figures (PDF for the paper, PNG for this page)
notebooks/       Colab notebook that recomputes all surprisal values
results/         numbers.txt and the data behind each figure
src/             Python scripts that build the measures
```

## Data sources and licenses

| Data | Source | License / terms |
|---|---|---|
| Child-directed utterances | CHILDES (MacWhinney, 2000), via childes-db | CC BY-NC-SA 4.0 ([TalkBank rules](https://talkbank.org/share/rules.html)) |
| Age of acquisition | Wordbank (Frank et al., 2017) | see [Wordbank](https://wordbank.stanford.edu) |
| Eye-tracking | MECO Wave 2 (Siegelman et al., 2025), [OSF](https://osf.io/3527a/) | see the MECO OSF project |
| Frequency norms | EsPal (Duchon et al., 2013); SUBTLEX-ESP (Cuetos et al., 2011) | see original sources |

The code is released under the MIT license ([LICENSE](LICENSE)). Data files keep the license of their source;
files in `data/derived/` that contain CHILDES utterances (`study1_contexts.csv`) are shared under
CC BY-NC-SA 4.0.

## Citation

If you use this code or data, please cite the paper (see [CITATION.cff](CITATION.cff)) and the original
data sources above.

## Use of AI tools

An AI assistant (Claude, Anthropic) helped write and check the analysis code, re-run and verify the
analyses, and prepare figures and documentation. All code was run and checked by the author.
