"""
study1_aoa_analysis.py
======================

Reproduces every statistic reported in Study 1 ("Surprisal and Age of
Acquisition in Spanish") of:

    From Exposure to Expectation: Frequency, Surprisal, and Language
    Across Development in Spanish

HOW TO RUN (in VS Code, or any terminal):
    1. Create a virtual environment (recommended):
         python -m venv venv
         source venv/bin/activate        # Windows: venv\\Scripts\\activate
    2. Install dependencies:
         pip install pandas numpy scipy
    3. Place df_paper_completo.csv in the same folder as this script.
    4. Run:
         python study1_aoa_analysis.py

WHAT df_paper_completo.csv CONTAINS:
    225 Spanish nouns (column 'item_definition') with:
      - AoA               : age of acquisition (Wordbank CDI norms)
      - frecuencia        : raw frequency count in child-directed speech
                            (CHILDES corpus)
      - n_contextos       : number of distinct CDS utterances containing
                            the noun (contextual diversity)
      - surprisal_real    : BETO surprisal, standardized carrier frames
      - surprisal_roberta : BERTIN surprisal, standardized carrier frames
      - surprisal_mgpt    : mGPT surprisal, standardized carrier frames

A NOTE ON DATA PROVENANCE (read this before trusting any number blindly):
    An earlier draft of this manuscript reported bivariate correlations
    for BETO/BERTIN/mGPT vs AoA (Table 1) that did NOT match what this
    script computes from df_paper_completo.csv -- the same file that DID
    correctly reproduce the incremental-R^2 regression results (Table 3).
    This discrepancy was caught by re-deriving every reported statistic
    directly from the underlying data file rather than trusting the
    manuscript text, and the manuscript was corrected to match the
    verified computation below. This is exactly why this script exists:
    every number in the published Table 1 should be reproducible by
    running this file, with no manual transcription step in between.
"""

import numpy as np
import pandas as pd
from scipy import stats as sstats

pd.set_option("display.precision", 4)


def ols(X, y, names):
    """Closed-form OLS with full inferential statistics (SE, t, p, R^2).

    Implemented from first principles (rather than calling a black-box
    regression function) so every number in the paper's regression
    tables is traceable to an explicit formula:
        beta      = (X'X)^-1 X'y
        Var(beta) = sigma^2 * (X'X)^-1,   sigma^2 = SSE / (n - k)
    """
    X = np.asarray(X, dtype=float)
    y = np.asarray(y, dtype=float)
    n, k = X.shape
    XtX_inv = np.linalg.inv(X.T @ X)
    beta = XtX_inv @ X.T @ y
    resid = y - X @ beta
    dof = n - k
    sigma2 = (resid @ resid) / dof
    se = np.sqrt(np.diag(sigma2 * XtX_inv))
    t = beta / se
    p = 2 * (1 - sstats.t.cdf(np.abs(t), dof))
    ss_res = resid @ resid
    ss_tot = np.sum((y - y.mean()) ** 2)
    r2 = 1 - ss_res / ss_tot
    return dict(zip(names, zip(beta, se, t, p))), r2, n


def zscore(x):
    """Standardize to mean 0, SD 1 (see Method: 'Statistical analysis')."""
    return (x - x.mean()) / x.std()


def spearman_partial(x, y, z):
    """Partial Spearman correlation of x and y, controlling for z.

    Computed as the Pearson partial-correlation formula applied to the
    RANKS of x, y, z (the standard definition of a partial Spearman
    correlation):
        r(xy.z) = (r_xy - r_xz*r_yz) / sqrt((1-r_xz^2)(1-r_yz^2))
    """
    rx, ry, rz = sstats.rankdata(x), sstats.rankdata(y), sstats.rankdata(z)
    r_xy, _ = sstats.pearsonr(rx, ry)
    r_xz, _ = sstats.pearsonr(rx, rz)
    r_yz, _ = sstats.pearsonr(ry, rz)
    partial = (r_xy - r_xz * r_yz) / np.sqrt((1 - r_xz**2) * (1 - r_yz**2))
    n = len(x)
    t = partial * np.sqrt((n - 3) / (1 - partial**2))
    p = 2 * (1 - sstats.t.cdf(np.abs(t), n - 3))
    return partial, p


def main():
    df = pd.read_csv("df_paper_completo.csv")
    df["word_length"] = df["item_definition"].str.len()

    # ====================================================================
    # TABLE 1: Spearman correlations between distributional predictors
    #          and AoA
    # ====================================================================
    print("=" * 72)
    print("TABLE 1: Spearman correlations with AoA")
    print("=" * 72)

    rho, p = sstats.spearmanr(df["frecuencia"], df["AoA"])
    print(f"Frequency (CDS):                    rho={rho:.3f}  p={p:.4f}  N={len(df)}")

    rho, p = sstats.spearmanr(df["n_contextos"], df["AoA"])
    print(f"Contextual diversity:               rho={rho:.3f}  p={p:.4f}")

    rho, p = spearman_partial(df["n_contextos"], df["AoA"], df["frecuencia"])
    print(f"Contextual diversity | frequency:   rho={rho:.3f}  p={p:.4f}")

    for label, col in [
        ("BETO", "surprisal_real"),
        ("BERTIN", "surprisal_roberta"),
        ("mGPT", "surprisal_mgpt"),
    ]:
        rho, p = sstats.spearmanr(df[col], df["AoA"])
        print(f"{label} surprisal (standardized):  rho={rho:.3f}  p={p:.4f}")

    print()
    print("Expected (as reported in the manuscript, verified against this")
    print("script): freq=-.597/<.001; diversity=-.564/<.001; diversity|freq=")
    print(".028/.680; BETO=-.036/.590; BERTIN=.102/.128; mGPT=-.048/.469")

    # ====================================================================
    # TABLE 3: Incremental R^2 from adding surprisal to a baseline model
    #          of frequency + word length (all predictors z-scored)
    # ====================================================================
    print()
    print("=" * 72)
    print("TABLE 3: Incremental R^2 (surprisal beyond frequency + length)")
    print("=" * 72)

    d = df.copy()
    d["freq_z"] = zscore(np.log1p(d["frecuencia"]))
    d["length_z"] = zscore(d["word_length"])
    d["AoA_z"] = zscore(d["AoA"])
    for c in ["surprisal_real", "surprisal_roberta", "surprisal_mgpt"]:
        d[c + "_z"] = zscore(d[c])

    Xb = np.column_stack([np.ones(len(d)), d["freq_z"], d["length_z"]])
    _, r2_base, n = ols(Xb, d["AoA_z"], ["const", "freq", "length"])
    print(f"Baseline (freq + word length): R^2={r2_base:.4f}  N={n}")

    for label, col in [
        ("BETO", "surprisal_real_z"),
        ("BERTIN", "surprisal_roberta_z"),
        ("mGPT", "surprisal_mgpt_z"),
    ]:
        Xf = np.column_stack([np.ones(len(d)), d["freq_z"], d["length_z"], d[col]])
        res, r2_full, n = ols(Xf, d["AoA_z"], ["const", "freq", "length", "surprisal"])
        beta, se, t, p = res["surprisal"]
        dr2 = r2_full - r2_base
        print(
            f"+ {label}: R^2={r2_full:.4f}  dR^2={dr2:.4f}  "
            f"beta={beta:.4f}  SE={se:.4f}  t={t:.3f}  p={p:.4f}"
        )

    print()
    print("Expected: baseline R^2~.379; BETO dR^2=.0023/beta=.048/p=.368;")
    print("BERTIN dR^2=.0067/beta=.082/p=.124; mGPT dR^2=.0006/beta=-.024/p=.653")

    # ====================================================================
    # TABLE 4 / natural-context analysis
    #
    # This requires re-computing mGPT surprisal over naturalistic CDS
    # utterances (up to 10 per noun, averaged), which requires running
    # mGPT itself and is therefore NOT reproduced in this lightweight
    # script. If you have a precomputed 'surprisal_mgpt_natural' column
    # (merge it into `df` before running this script), the procedure is:
    #
    #   rho, p = sstats.spearmanr(df['surprisal_mgpt_natural'], df['AoA'])
    #   # then the same incremental-R^2 regression as Table 3, substituting
    #   # surprisal_mgpt_natural for surprisal_mgpt
    #
    # Expected values: full sample (N=224) rho=.153/p=.022, dR^2=.0008,
    # beta=-.0209, p=.595; restricted sample (N=154, >=5 contexts)
    # rho=.132/p=.104, dR^2=.0076, beta=-.0737, p=.197.
    # ====================================================================
    print()
    print("=" * 72)
    print("NATURAL-CONTEXT ANALYSIS: requires precomputed mGPT surprisal")
    print("over naturalistic CDS contexts -- see comment above. Not run here.")
    print("=" * 72)

    # ====================================================================
    # Word-type-level mGPT-vs-AoA correlation, needed for the Study-2
    # script's Fisher r-to-z comparison.
    # ====================================================================
    print()
    print("=" * 72)
    print("Value needed by study2 script for the Fisher r-to-z comparison:")
    print("=" * 72)
    rho, _ = sstats.spearmanr(df["surprisal_mgpt"], df["AoA"])
    print(f"mGPT surprisal (standardized) vs AoA: rho={rho:.4f}, N={len(df)}")


if __name__ == "__main__":
    main()
