# Reproducibility package

Code to reproduce every statistic reported in:

> From Exposure to Expectation: Frequency, Surprisal, and Language
> Across Development in Spanish

Organized as two independent studies. Each folder is self-contained;
you do not need to run Study 1 to run Study 2 or vice versa.

## Folder structure

```
study1/
  study1_aoa_analysis.py          -- run this (pure Python)
  df_paper_completo.csv           -- input data (225 Spanish nouns;
                                      the author's own compiled dataset
                                      -- see "A note on data licensing")

study2/
  study2_data_prep.py             -- run this FIRST (pure Python)
  study2_mixed_models.R           -- run this SECOND (R)
  surprisal_mgpt_checkpoint.json  -- input: precomputed mGPT surprisal
                                      (the author's own model output)
```

You will need to separately download three third-party files before
running Study 2 -- see "Downloading the required third-party data"
below. They are not included in this repository because their
redistribution terms were not clearly documented at the time of
writing (see "A note on data licensing").

## Setup (once)

```bash
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install pandas numpy scipy openpyxl pyreadr
```

For Study 2's mixed models, you additionally need R with two packages
(install once, from an R console):

```r
install.packages(c("lme4", "lmerTest"))
```

## Running Study 1

```bash
cd study1
python study1_aoa_analysis.py
```

Prints every statistic in Tables 1 and 3, with the expected published
values shown alongside for direct comparison.

## Downloading the required third-party data (for Study 2)

Place these three files in the `study2/` folder before running
`study2_data_prep.py`:

1. **MECO Wave 2 raw data** -- `joint_data_trimmed_wave2_version2_0.rda`
   Download from the official OSF repository: https://osf.io/3527a/
   (navigate to: release 2.0 / version 2.0 / wave 2 / primary data /
   eye tracking data). Check the license/terms displayed on that OSF
   page before redistributing this file yourself elsewhere.

2. **EsPal frequency norms** -- `written_es_wordlist_out.txt`
   Generate this from the EsPal web interface:
   https://www.bcbl.eu/databases/espal/
   Use the "Words to Properties" tool and request the `zipf` and
   `num_letters` fields.

3. **SUBTLEX-ESP frequency norms** -- `SUBTLEX-ESP.xlsx`
   Download from: https://osf.io/xp6sz/
   Cite: Cuetos, Glez-Nosti, Barbón, & Brysbaert (2011), *Psicológica*,
   32(2), 133-143.

## Running Study 2

```bash
cd study2
# (place the three downloaded files here first)
python study2_data_prep.py        # produces meco_analysis_dataset.csv
Rscript study2_mixed_models.R     # or run interactively in VS Code
```

`study2_data_prep.py` loads the MECO `.rda` directly via `pyreadr` and
filters it to the Chilean Spanish subsample (`lang == "sp_ch"`). See
`load_meco_chilean_spanish()` in that file.

### Why two languages (Python + R) in one pipeline?

Data cleaning and merging (Python) and mixed-effects model fitting (R)
are kept separate deliberately. The models used here have **crossed**
random effects for participant and word type (each participant read
every passage; each word type was read by many participants, so
neither is nested inside the other). R's `lme4` package uses
sparse-matrix methods purpose-built for exactly this scenario and is
the standard tool for this kind of design in psycholinguistics.
Python's `statsmodels.MixedLM` was attempted first and did not
converge in practical time for the 888 word types here -- see the
comment header of `study2_mixed_models.R` for details. The underlying
statistical model is identical either way; only the computational
engine differs.

## A note on data licensing

This repository includes only data that the author generated or
compiled directly:

- `df_paper_completo.csv` (Study 1): the author's own merged dataset
  combining publicly available AoA norms (Wordbank), CHILDES frequency
  counts, and the author's own LLM surprisal computations.
- `surprisal_mgpt_checkpoint.json` (Study 2): the author's own mGPT
  surprisal computations over the MECO passages.

It deliberately does NOT include the raw third-party databases (MECO,
EsPal, SUBTLEX-ESP) themselves, because their redistribution terms
were not clearly documented as permitting re-hosting on a third
party's public repository at the time this package was assembled.
Please download them directly from their official sources (links
above), and check each source's current license/terms before
redistributing them yourself.

## A transparency note on Table 1

An earlier version of the manuscript reported bivariate correlations
in Table 1 (BETO/BERTIN/mGPT vs. AoA) that did not match direct
computation from `df_paper_completo.csv` -- the same file that
correctly reproduces the Table 3 regression results. This was caught
by re-deriving every reported statistic from the underlying data
rather than trusting the manuscript text, and the manuscript was
corrected accordingly (including the downstream Fisher r-to-z
comparison, reported in the General Discussion). Running
`study1_aoa_analysis.py` reproduces the corrected values.
