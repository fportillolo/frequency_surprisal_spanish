# study2_mixed_models.R
# ======================
#
# Fits the mixed-effects models reported in Table 2 and Figure 3 of
# Study 2 ("Surprisal and Adult Reading Times in Spanish").
#
# HOW TO RUN (in VS Code with the R extension, or from a terminal):
#   1. Install R (https://www.r-project.org) if not already installed.
#   2. From an R console, install dependencies once:
#        install.packages(c("lme4", "lmerTest"))
#   3. Run study2_data_prep.py first to produce
#      meco_analysis_dataset.csv in this same folder.
#   4. Run this script:
#        Rscript study2_mixed_models.R
#      (or open it in VS Code with the R extension and run interactively)
#
# WHY R / lme4 INSTEAD OF PYTHON:
#   The model below uses CROSSED random effects for participant and word
#   type: each participant read all 12 passages, and each word type was
#   read by many different participants, so neither is nested inside the
#   other. We first attempted this in Python (statsmodels.MixedLM, using
#   its vc_formula mechanism for crossed effects); with 888 word-type
#   levels, it did not converge within 20+ minutes. R's lme4 package uses
#   sparse-matrix methods purpose-built for exactly this crossed,
#   non-nested random-effects scenario (it is, in fact, the standard tool
#   for this kind of design in psycholinguistics) and converges in
#   seconds. The statistical MODEL is identical either way; only the
#   computational engine differs.

library(lme4)
library(lmerTest)  # adds Satterthwaite-approximated p-values on top of
                    # lme4's fixed-effect estimates. lme4 deliberately
                    # omits p-values by default because the correct
                    # denominator degrees of freedom is not closed-form
                    # in unbalanced mixed models; Satterthwaite's
                    # approximation is the standard solution.

d <- read.csv("meco_analysis_dataset.csv")
d$subid <- as.factor(d$subid)
d$word_clean <- as.factor(d$word_clean)

cat(sprintf("Loaded %d observations, %d participants, %d word types.\n",
            nrow(d), nlevels(d$subid), nlevels(d$word_clean)))
cat("(Manuscript reports N=46,442 / 45 participants / 888 word types.)\n\n")

# ---------------------------------------------------------------------
# MODEL A: EsPal frequency
#
#   log(fixation duration) ~ surprisal + frequency + word_length
#                             + (1 | participant) + (1 | word type)
#
# The two random-intercept terms are CROSSED, not nested: "(1|subid) +
# (1|word_clean)" tells lme4 to estimate a separate baseline reading
# speed per participant AND a separate baseline difficulty per word
# type, simultaneously, rather than assuming one is a subgroup of the
# other.
# ---------------------------------------------------------------------
cat(strrep("=", 70), "\n")
cat("MODEL A (EsPal frequency)\n")
cat(strrep("=", 70), "\n")
modelo_a <- lmer(
  log_dur ~ surprisal_mgpt + freq_espal + num_letters +
    (1 | subid) + (1 | word_clean),
  data = d, REML = TRUE
)
print(summary(modelo_a))

# ---------------------------------------------------------------------
# MODEL B: SUBTLEX-ESP frequency (robustness check with an independent
# frequency norm; EsPal and SUBTLEX-ESP correlate at r=.95 but come from
# different sources -- corpus-derived Zipf norms vs. film subtitles --
# so replicating the surprisal effect across both rules out the
# possibility that it is an artifact of one particular frequency
# measure).
# ---------------------------------------------------------------------
cat("\n", strrep("=", 70), "\n", sep = "")
cat("MODEL B (SUBTLEX-ESP frequency)\n")
cat(strrep("=", 70), "\n")
modelo_b <- lmer(
  log_dur ~ surprisal_mgpt + freq_subtlex + num_letters +
    (1 | subid) + (1 | word_clean),
  data = d, REML = TRUE
)
print(summary(modelo_b))

# ---------------------------------------------------------------------
# STANDARDIZED MODEL: all continuous variables z-scored, same crossed
# random-effects structure, so the three fixed-effect coefficients are
# directly comparable in units of "SDs of log(duration) per SD of
# predictor" (this is what Figure 3 plots).
# ---------------------------------------------------------------------
cat("\n", strrep("=", 70), "\n", sep = "")
cat("STANDARDIZED MODEL (relative magnitude of predictors, Figure 3)\n")
cat(strrep("=", 70), "\n")
d$z_surprisal  <- scale(d$surprisal_mgpt)[, 1]
d$z_freq_espal <- scale(d$freq_espal)[, 1]
d$z_letters    <- scale(d$num_letters)[, 1]
d$z_logdur     <- scale(d$log_dur)[, 1]

modelo_z <- lmer(
  z_logdur ~ z_surprisal + z_freq_espal + z_letters +
    (1 | subid) + (1 | word_clean),
  data = d, REML = TRUE
)
print(summary(modelo_z))
cat("\n95% Wald confidence intervals:\n")
print(confint(modelo_z, method = "Wald"))

# ---------------------------------------------------------------------
# Expected results (as reported in the manuscript; Table 2 and the
# "Relative magnitude of predictors" subsection):
#   Model A: surprisal beta=0.0114 (SE=.00067, t=17.19, p<.001)
#   Model B: surprisal beta=0.0114 (SE=.00066, t=17.33, p<.001)
#   Random effects: item variance ~0.020, participant variance ~0.035
#   Standardized: length beta=.292, surprisal beta=.112, freq beta=-.051
# ---------------------------------------------------------------------
cat("\nDone. Compare the estimates above against Table 2 and the\n")
cat("'Relative magnitude of predictors' subsection of the manuscript.\n")
