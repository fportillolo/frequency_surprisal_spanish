"""
study2_data_prep.py
====================

Builds the final analysis dataset for Study 2 ("Surprisal and Adult
Reading Times in Spanish", MECO Wave 2) from raw inputs. This script
handles everything that can be done in Python; the mixed-effects models
themselves are fit separately in R (see study2_mixed_models.R), because
R's lme4 package handles the crossed random-effects structure used here
(participant x word type) far more efficiently than Python alternatives
-- see the long comment in study2_mixed_models.R for why.

HOW TO RUN (in VS Code, or any terminal):
    1. Create/activate a virtual environment, then:
         pip install pandas numpy openpyxl pyreadr
    2. Download these three files and place them in the same folder as
       this script (they are NOT bundled with this repository -- see
       the top-level README.md, "Downloading the required third-party
       data", for exact download links):
         - joint_data_trimmed_wave2_version2_0.rda
             (public MECO Wave 2 data: https://osf.io/3527a/)
         - written_es_wordlist_out.txt (EsPal frequency norms:
             https://www.bcbl.eu/databases/espal/)
         - SUBTLEX-ESP.xlsx (SUBTLEX-ESP frequency norms:
             https://osf.io/xp6sz/)
    3. Make sure surprisal_mgpt_checkpoint.json (bundled with this
       repository -- it is the author's own precomputed output) is
       also in this folder.
    4. Run:
         python study2_data_prep.py
       This produces meco_analysis_dataset.csv, which
       study2_mixed_models.R reads as its input.

VERIFICATION NOTE: every filtering step below was chosen because it
reproduces the exact N=46,442 reported in the manuscript. This was
confirmed empirically -- e.g., using .lower() alone instead of the
regex-based word-cleaning function below recovers a smaller N and does
NOT match the reported sample size.
"""

import re
import json
import numpy as np
import pandas as pd


def limpiar_palabra(w):
    """Lowercase and strip all non-alphanumeric characters (including
    Spanish accented vowels and enye), so that e.g. 'casa,' and '"casa"'
    match the same frequency-norm entry as 'casa'."""
    return re.sub(r"[^\wáéíóúñüÁÉÍÓÚÑÜ]", "", str(w).lower())


def load_meco_chilean_spanish(rda_path):
    """Load MECO Wave 2 and filter to the Chilean Spanish subsample.

    IMPORTANT: the MECO codebook explicitly instructs users NOT to use
    'subid'/'itemid' and to use 'uniform_id'/'trialid' instead (they are
    legacy columns). We verify here -- rather than assume -- that within
    the Chilean Spanish subsample, subid<->uniform_id and itemid<->trialid
    are perfect 1:1 mappings (just different label formats), so using
    subid/itemid downstream does not introduce any error.
    """
    import pyreadr

    result = pyreadr.read_r(rda_path)
    df_all = result[list(result.keys())[0]]
    df_es = df_all[df_all["lang"] == "sp_ch"].copy()
    df_es["itemid"] = df_es["itemid"].astype(str)

    assert (df_es["itemid"].astype(float) == df_es["trialid"].astype(float)).all(), \
        "itemid/trialid mismatch -- investigate before proceeding"
    map1 = df_es.groupby("subid")["uniform_id"].nunique()
    map2 = df_es.groupby("uniform_id")["subid"].nunique()
    assert (map1 == 1).all() and (map2 == 1).all(), \
        "subid/uniform_id is not a clean 1:1 mapping -- investigate before proceeding"

    print(f"Loaded MECO sp_ch: {len(df_es)} rows, "
          f"{df_es['subid'].nunique()} participants, "
          f"{df_es['itemid'].nunique()} passages. "
          f"subid/itemid verified safe to use as identifiers.")
    return df_es


def merge_surprisal(df_es, surprisal_json_path):
    """Reconstruct each passage's word sequence in reading order and
    align it, position by position, with the precomputed mGPT surprisal
    for that passage."""
    pasajes = (
        df_es.dropna(subset=["word"])
        .drop_duplicates(subset=["itemid", "sentnum", "wordnum"])
        .sort_values(["itemid", "sentnum", "wordnum"])
        .groupby("itemid")
        .apply(lambda g: g[["sentnum", "wordnum", "word"]].to_dict("records"),
               include_groups=False)
        .to_dict()
    )

    with open(surprisal_json_path) as f:
        surprisal_by_passage = json.load(f)

    rows = []
    for itemid, records in pasajes.items():
        surp_list = surprisal_by_passage[itemid]
        assert len(surp_list) == len(records), (
            f"passage {itemid}: length mismatch between reconstructed "
            f"text ({len(records)} words) and surprisal checkpoint "
            f"({len(surp_list)} values)"
        )
        for rec, s in zip(records, surp_list):
            rows.append({
                "itemid": itemid, "sentnum": rec["sentnum"],
                "wordnum": rec["wordnum"], "surprisal_mgpt": s,
            })
    df_surp = pd.DataFrame(rows)

    df_merged = df_es.merge(df_surp, on=["itemid", "sentnum", "wordnum"], how="left")
    n_missing = df_merged["surprisal_mgpt"].isna().sum()
    print(f"Merged surprisal: {n_missing} rows have no surprisal value "
          f"(these are occurrences of the first word of each of the 12 "
          f"passages -- one such occurrence per participant who read that "
          f"passage, since this dataframe has one row per "
          f"participant-word-position combination, not one row per "
          f"unique passage position).")
    return df_merged


def merge_frequency_norms(df_merged, espal_path, subtlex_path):
    df_merged = df_merged.copy()
    df_merged["word_clean"] = df_merged["word"].apply(limpiar_palabra)

    # --- EsPal ---
    espal = pd.read_csv(espal_path, sep="\t", encoding="utf-8-sig")
    espal.columns = [c.strip() for c in espal.columns]
    espal["word_clean"] = espal["word"].str.lower().str.strip()
    espal_small = espal[["word_clean", "zipf", "num_letters"]].drop_duplicates("word_clean")
    df_merged = df_merged.merge(espal_small, on="word_clean", how="left")
    df_merged = df_merged.rename(columns={"zipf": "freq_espal"})

    # --- SUBTLEX-ESP: distributed as 3 side-by-side word/frequency
    #     blocks per Excel row; stack them into one long table ---
    from openpyxl import load_workbook

    wb = load_workbook(subtlex_path, read_only=True)
    data_rows = list(wb.active.iter_rows(values_only=True))[1:]
    blocks = []
    for start in [0, 5, 10]:
        block = [(r[start], r[start + 1], r[start + 2], r[start + 3])
                 for r in data_rows if r[start] is not None]
        blocks.append(pd.DataFrame(block, columns=["word", "cnt", "per_million", "log_freq"]))
    subtlex = pd.concat(blocks, ignore_index=True)
    subtlex["word_clean"] = subtlex["word"].astype(str).str.lower().str.strip()
    subtlex = subtlex.drop_duplicates("word_clean")
    df_merged = df_merged.merge(
        subtlex[["word_clean", "log_freq"]], on="word_clean", how="left"
    ).rename(columns={"log_freq": "freq_subtlex"})

    return df_merged


def apply_exclusions(df_merged):
    """Apply the three exclusion criteria described in the paper's Method
    (Participants and materials), in order:
        (a) exclude the first word of every passage (no preceding context
            for surprisal estimation)
        (b) exclude words without a match in EITHER frequency norm
        (c) exclude skipped words (no fixation recorded -> not a
            meaningful reading-time observation)
    """
    d = df_merged[df_merged["surprisal_mgpt"].notna()].copy()      # (a)
    d = d[d["freq_espal"].notna() & d["freq_subtlex"].notna()]     # (b)
    d = d[d["dur"].notna() & (d["dur"] > 0)]                       # (c)
    d["log_dur"] = np.log(d["dur"])
    return d


def main():
    df_es = load_meco_chilean_spanish("joint_data_trimmed_wave2_version2_0.rda")
    df_merged = merge_surprisal(df_es, "surprisal_mgpt_checkpoint.json")
    df_merged = merge_frequency_norms(
        df_merged, "written_es_wordlist_out.txt", "SUBTLEX-ESP.xlsx"
    )
    d = apply_exclusions(df_merged)

    print()
    print(f"Final analysis dataset: N={len(d)} "
          f"(manuscript reports N=46,442 -- must match exactly)")
    print(f"  Participants: {d['subid'].nunique()} (manuscript: 45)")
    print(f"  Word types:   {d['word_clean'].nunique()} (manuscript: 888)")

    d.to_csv("meco_analysis_dataset.csv", index=False)
    print("\nSaved meco_analysis_dataset.csv -- ready for study2_mixed_models.R")


if __name__ == "__main__":
    main()
